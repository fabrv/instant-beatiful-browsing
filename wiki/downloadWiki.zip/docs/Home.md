[Screen Shots](Screen-Shots)
![](Home_standarColor.png)
Instant Beautiful Browsing is a application that mimics the Windows 8 metro interface. This application can be used in case you wanna have the Windows 8 metro interface on your machine without the need of installing a new Operative System. 
In the near future IBB will include more built-in apps like
	* Calendar
	* Store
	* Music
	* Google
	* Lock Screen
	* Setting
	* Share Hub
	* Devices Hub
	* Search Hub

![](Home_banner1.png)