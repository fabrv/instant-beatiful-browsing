# Screen Shots:


**Windows 8 Comparison**
![](Screen Shots_screenshotbanners.png)
**Web Apps (here 9gag.com app)**
![](Screen Shots_Screenshot (58).png)